package com.clonespace.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap

data class InstalledApp(
    val label: String,
    val packageName: String,
    val icon: Drawable
)

class CloneStore(context: Context) {
    private val prefs = context.getSharedPreferences("clones", Context.MODE_PRIVATE)

    fun count(packageName: String): Int =
        prefs.getInt("count_$packageName", 0)

    fun setCount(packageName: String, count: Int) {
        prefs.edit().putInt("count_$packageName", count).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CloneSpaceApp(this)
            }
        }
    }
}

@Composable
fun CloneSpaceApp(context: Context) {
    val pm = context.packageManager
    val store = remember { CloneStore(context) }

    var apps by remember { mutableStateOf(loadApps(pm)) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<InstalledApp?>(null) }

    val filtered = apps.filter {
        it.label.contains(search, ignoreCase = true) ||
        it.packageName.contains(search, ignoreCase = true)
    }

    if (selected == null) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("CloneSpace") })
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().padding(16.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Search installed apps") }
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Choose an app to create up to 5 isolated clone slots.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered) { app ->
                        AppRow(
                            app = app,
                            cloneCount = store.count(app.packageName),
                            onClick = { selected = app }
                        )
                    }
                }
            }
        }
    } else {
        CloneDetail(
            app = selected!!,
            count = store.count(selected!!.packageName),
            onBack = { selected = null },
            onChange = { newCount ->
                store.setCount(selected!!.packageName, newCount)
                selected = selected
            }
        )
    }
}

@Composable
fun AppRow(app: InstalledApp, cloneCount: Int, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                bitmap = app.icon.toBitmap(64, 64).asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(48.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (cloneCount == 0) "No clones" else "$cloneCount/5 clone slots",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(onClick = onClick) { Text("Clone") }
        }
    }
}

@Composable
fun CloneDetail(
    app: InstalledApp,
    count: Int,
    onBack: () -> Unit,
    onChange: (Int) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(app.label) },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(20.dp)
        ) {
            Text("Clone slots", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text("Create up to 5 independent clone profiles for this app.")
            Spacer(Modifier.height(20.dp))

            for (slot in 1..5) {
                val active = slot <= count
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("${app.label}-$slot")
                            Text(
                                if (active)
                                    "Clone slot reserved"
                                else
                                    "Available",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (!active) {
                            OutlinedButton(
                                onClick = { onChange(slot) },
                                enabled = count < 5
                            ) { Text("Create") }
                        } else {
                            Text("✓", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            HorizontalDivider()
            Spacer(Modifier.height(18.dp))
            Text(
                "Prototype note: this build contains the clone manager and app inventory. " +
                "The actual isolated runtime is a separate engine layer and is intentionally not " +
                "pretended to be implemented here.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun loadApps(pm: PackageManager): List<InstalledApp> {
    val intent = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }

    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { resolve ->
            val info = resolve.activityInfo?.applicationInfo ?: return@mapNotNull null
            if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0 &&
                info.packageName == "com.android.settings") {
                return@mapNotNull null
            }
            InstalledApp(
                label = info.loadLabel(pm).toString(),
                packageName = info.packageName,
                icon = info.loadIcon(pm)
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

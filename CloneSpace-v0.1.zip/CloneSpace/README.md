# CloneSpace — Android App Cloner Prototype

This is Version 0.1 of the requested cloning-only app.

## Included
- Lists launchable installed Android apps.
- Search.
- Select an app.
- Up to 5 clone slots per app.
- Clone names: App-1 ... App-5.
- Local clone-slot management.
- No ads, downloader, vault or unrelated features.

## Important
This prototype does **not** yet run the target APK inside an isolated virtual Android environment.
Android does not provide a public API that lets a normal third-party app simply duplicate another
installed app's private data/process into five independent app processes.

The next engine layer needs either:
1. A properly licensed/compatible application-virtualization SDK, or
2. A custom virtualization/container implementation.

VirtualApp's public GitHub repository explicitly states that its public code is old and that current
commercial code requires a license. Therefore this project does not copy or bundle VirtualApp code.

## Build
Open the folder in Android Studio and let Gradle sync.
Run on an Android device/emulator.

## Roadmap
- Runtime engine integration
- Install/launch cloned APKs inside isolated users
- Notifications
- Separate storage
- Per-clone name/icon
- Clone delete/reset
- Compatibility testing on Android 12–17
